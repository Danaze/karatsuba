# -*- coding: utf-8 -*-
"""
Created on Thu Nov 11 22:42:07 2021

@author: daaze
"""

#!/usr/bin/env python

from distutils.core import setup

setup(name='karatsuba-dagne',
      version='0.1',
      description='karatsuba recursive implementation',
      author='Dagne',
     )

